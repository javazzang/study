package shop.javac.web.kor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KorApplication {

	public static void main(String[] args) {
		SpringApplication.run(KorApplication.class, args);
	}

}
